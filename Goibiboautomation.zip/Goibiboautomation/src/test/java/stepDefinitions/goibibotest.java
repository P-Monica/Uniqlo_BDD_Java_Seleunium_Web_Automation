package stepDefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.junit.Cucumber;
import wipro.project.page.Pageclass;

import java.awt.AWTException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import Resources.Baseclass;
import Resources.Screenshot;

@RunWith(Cucumber.class)

public class goibibotest {
	WebDriver driver;

	//ExtentReports report;
	
	//ExtentTest logger; 
	
	String baseUrl=" ";
	 
	
	 Baseclass b=new Baseclass();
	 Pageclass page;
	 
	 @Given("^User is on goibibo page and enter details$")
    public void user_is_on_goibibo_page() throws IOException, AWTException, InterruptedException  {
		    	
    	b.launchBrowser();
		 driver=new ChromeDriver();
		 //driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
		 baseUrl=b.goibibolink();
		 driver.get(baseUrl);
		 
		 page=new Pageclass(driver);
		/*
		 * report=new
		 * ExtentReports("E:\\Java_Workspace\\Automation Project\\Goibiboreport\\goibibo.html"
		 * ); logger=report.startTest("bookflight");
		 */
		
			 //logger.log(LogStatus.INFO, "Browser started ");
			 driver.manage().window().maximize();

			 page.trip();
	         page.enterfrom();
		     page.enterTo();
			 page.trip_callink();
			 page.trip_fromdate();
			 page.trip_tocallink();
			 page.trip_todate();
		     page. trip_eclass();
		     page.trip_selecteco();
			 page.trip_search();
			 
		    String img1=Screenshot.takeSnapshot(driver);
		   // logger.log(LogStatus.PASS,logger.addScreenCapture(img1)+ "TestPassed");
    	
    }

	 
	 @When("^Book the flight by clicking on book now$")
    public void user_enter_the_required_details_to_search_flight() throws AWTException, IOException
	  {
		 
		page.trip_booknow();
        
    }

	 @Then("^User should be able to view the booked flights$")
    public void flight_details_are_displayed() throws IOException
	  {
		  
		  String url=driver.getCurrentUrl();
		driver.quit();
		  
    }

}