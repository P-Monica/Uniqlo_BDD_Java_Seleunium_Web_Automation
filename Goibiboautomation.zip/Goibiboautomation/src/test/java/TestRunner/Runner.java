package TestRunner;

import org.junit.runner.RunWith;
import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;		
import cucumber.api.junit.Cucumber;		
@Test
//@RunWith annotation tells junit that tests should run using cucumber class present in Cucumber.api.junit package 
@RunWith(Cucumber.class)	

// This annotation will take 2 inputs one is where feature file is located and second is where the stepdefinition file is located
//glue is a parameter to define our stepdefintion file
@CucumberOptions(features="src\\test\\java\\Features",glue="stepDefinitions")	

public class Runner 				
{		

}