package Resources;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Baseclass {
	public void launchBrowser()throws IOException
	{
		FileReader reader=new FileReader("Configuration.properties");  
		Properties p=new Properties();  
		
	    p.load(reader);  
	      
	   // System.out.println(p.getProperty("browser"));  
	    
	    String bro=p.getProperty("browser");
	    if(bro.equals("chrome"))
	    {
	    	System.setProperty("webdriver.chrome.driver", "E:\\Java_Workspace\\Automation Project\\Goibiboautomation\\chromedriver.exe");	
	    }
	  	      
	}
	
	public String goibibolink() throws IOException
	{
		FileReader reader=new FileReader("Configuration.properties");  
		Properties p=new Properties();  
		
	    p.load(reader);  
	      
	    System.out.println(p.getProperty("goibibourl"));  
	    
	    String launchurl=p.getProperty("goibibourl");
	    
	    return launchurl;
	    
	    
	}
 
}
