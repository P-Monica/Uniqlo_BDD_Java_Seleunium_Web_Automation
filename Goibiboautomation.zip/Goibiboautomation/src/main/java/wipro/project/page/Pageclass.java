package wipro.project.page;


import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Pageclass 
{
WebDriver driver;

@FindBy(xpath="//span[contains(text(),'One way')]")
WebElement oneway;

@FindBy(xpath="//input[@id='gosuggest_inputSrc']")
WebElement from;

@FindBy(xpath="//input[@id='gosuggest_inputDest']")
WebElement to;

@FindBy(xpath="//input[@id='departureCalendar']")
WebElement callink;
		
@FindBy(xpath="//div[@aria-label='Wed Jul 29 2020']")
WebElement fromdate;

@FindBy(xpath="//input[@id='returnCalendar']")
WebElement tocallink;

@FindBy(xpath="//div[@aria-label='Fri Jul 31 2020']")
WebElement todate;

@FindBy(xpath="//div[@id='pax_link_common']")
WebElement eclass;

@FindBy(xpath="//select[@id='gi_class']")
WebElement selecteco;

@FindBy(xpath="//a[@id='pax_close']")
WebElement close ;

@FindBy(xpath="//*[@id='gi_search_btn']")
WebElement search;

@FindBy(xpath="//input[@type='button']")
WebElement booknow;

public Pageclass(WebDriver driver)
{
	this.driver=driver;
	PageFactory.initElements(driver, this);
}

public void trip()
{
	 oneway.click();
}

public void enterfrom()
{
		
	 Actions actions = new Actions(driver); 
     from.click();
     from.clear();
     from.sendKeys("Chennai (MAA)");
     actions.clickAndHold(from).sendKeys(from, Keys.DOWN).sendKeys(from, Keys.ENTER).build().perform();
}
public void enterTo()
{
		 
	   Actions actions = new Actions(driver); 
	   to.click();
       to.clear();
       to.sendKeys("Bengaluru (BLR)");
       actions.clickAndHold(to).sendKeys(to, Keys.DOWN).sendKeys(to, Keys.ENTER).build().perform();
}

public void trip_callink()
{
	callink.click();
}

public void trip_fromdate()
{
	fromdate.click();
}

public void trip_tocallink()
{
	tocallink.click();
}

public void trip_todate()
{
	todate.click();
}

public void trip_eclass()
{
	eclass.click();
}

public void trip_selecteco()
{
	Select sel=new Select(selecteco);
	sel.selectByIndex(0);
}

public void trip_close()
{
	close.click();
}
public void trip_search()
{
	search.click();
}

public void trip_booknow()
{
	booknow.click();
}


}
